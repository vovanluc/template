<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-US">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Online Bass Lessons &lsaquo; Log In</title>
	    <link rel="stylesheet" id="custom_wp_admin_css"  href="https://www.scottsbasslessons.com/wp-content/themes/sbl/styles/custom-admin.css" type="text/css" media="all" />
<link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript' src='https://www.scottsbasslessons.com/wp-admin/load-scripts.php?c=0&amp;load%5B%5D=jquery-core,jquery-migrate&amp;ver=4.7.5'></script>
<link rel='stylesheet' href='https://www.scottsbasslessons.com/wp-admin/load-styles.php?c=0&amp;dir=ltr&amp;load%5B%5D=dashicons,buttons,forms,l10n,login&amp;ver=4.7.5' type='text/css' media='all' />

<style type="text/css">
html, body { border:0 !important; background:none !important; }
html { background-color:#FFFFFF !important; }
html { background-image:url() !important; }
html { background-repeat:repeat !important; }
@media (max-width: 767px) { html, body { background-size: contain  !important; } }
body, body * { font-size:12px !important; }
body, body * { font-family:'Verdana', 'Arial', sans-serif !important; }
div#login { width: 100%  !important; max-width:300px !important; }
div#login h1 a { background:url(http://scottsbasslessons.com/wp-content/uploads/2012/11/Logo-Full-300x67.png) no-repeat top center !important; background-size:contain !important; }
div#login h1 a { display:block !important; width:100% !important; height:67px !important; }
div#login form { box-shadow:1px 1px 2px #EEEEEE, -1px -1px 2px #EEEEEE !important; border-radius:5px !important; padding-bottom:16px !important; }
div#login p#nav, div#login p#nav a, div#login p#nav a:hover, div#login p#nav a:active, div#login p#nav a:focus { color:#000000 !important; text-shadow:1px 1px 3px #EEEEEE !important; }
div#login p#backtoblog, div#login p#backtoblog a, div#login p#backtoblog a:hover, div#login p#backtoblog a:active, div#login p#backtoblog a:focus { color:#000000 !important; text-shadow:1px 1px 3px #EEEEEE !important; }
div#login form p { margin:2px 0 16px 0 !important; }
div#login form input[type="text"], div#login form input[type="email"], div#login form input[type="password"], div#login form textarea, div#login form select { margin:0 !important; padding:3px !important; border-radius:3px !important; box-sizing:border-box !important; width:100% !important; background:#FBFBFB repeat scroll 0 0 !important; border:1px solid #E5E5E5 !important; font-size:18px !important; font-weight:normal !important; color:#333333 !important; }
@supports (-moz-appearance: none){ div#login form select { font-size:15px !important; } }
div#login form label { cursor:pointer !important; } div#login form label.ws-plugin--s2member-custom-reg-field-op-l { opacity:0.7 !important; font-size:90% !important; vertical-align:middle !important; }
div#login form input[type="checkbox"], div#login form input[type="radio"] { margin:0 3px 0 0 !important; vertical-align:middle !important; }
div#login form input#ws-plugin--s2member-custom-reg-field-user-pass2[type="password"] { margin-top:5px !important; }
div#login form div.ws-plugin--s2member-custom-reg-field-divider-section { margin:2px 0 16px 0 !important; border:0 !important; height:1px !important; line-height:1px !important; background:#CCCCCC !important; }
div#login form div.ws-plugin--s2member-custom-reg-field-divider-section-title { margin:2px 0 16px 0 !important; border:0 solid #CCCCCC !important; border-width:0 0 1px 0 !important; padding:0 0 10px 0 !important; font-size:110% !important; }
div#login form input[type="submit"], div#login form input[type="submit"]:hover, div#login form input[type="submit"]:active, div#login form input[type="submit"]:focus { color:#666666 !important; text-shadow:2px 2px 5px #EEEEEE !important; border:1px solid #999999 !important; border-radius:3px !important; background:#FBFBFB !important; box-shadow:0 -1px 2px 0 rgba(0,0,0,0.2) inset !important; }
div#login form input[type="submit"]:hover, div#login form input[type="submit"]:active, div#login form input[type="submit"]:focus { color:#000000 !important; text-shadow:2px 2px 5px #CCCCCC !important; border-color:#000000 !important; }
div#login form#registerform p.submit { float:none !important; margin-top:-10px !important; } div#login form#registerform input[type="submit"] { float:none !important; width:100% !important; box-sizing:border-box !important; }
div#login form#lostpasswordform p.submit { float:none !important; } div#login form#lostpasswordform input[type="submit"] { float:none !important; width:100% !important; box-sizing:border-box !important; }
div#login form#resetpassform #pass-strength-result { float:none !important; width:100% !important; box-sizing:border-box !important; } div#login form#resetpassform p.submit { float:none !important; } div#login form#resetpassform input[type="submit"] { float:none !important; width:100% !important; box-sizing:border-box !important; }
div.ws-plugin--s2member-password-strength { margin-top:3px !important; font-color:#000000 !important; background-color:#EEEEEE !important; padding:3px !important; border-radius:3px !important; } div.ws-plugin--s2member-password-strength-short { background-color:#FFA0A0 !important; } div.ws-plugin--s2member-password-strength-weak { background-color:#FFB78C !important; } div.ws-plugin--s2member-password-strength-good { background-color:#FFEC8B !important; } div.ws-plugin--s2member-password-strength-strong { background-color:#C3FF88 !important; } div.ws-plugin--s2member-password-strength-mismatch { background-color:#D6C1AB !important; }
div#login form#registerform p#reg_passmail { font-style:italic !important; }
div#login form#registerform p#reg_passmail { display:none !important; }
div#login p#backtoblog { display:none !important; }
</style>

<meta name='robots' content='noindex,follow' />
	<meta name="viewport" content="width=device-width" />
		</head>
	<body class="login login-action-login wp-core-ui  locale-en-us">
		<div id="login">
		<h1><a href="http://www.scottsbasslessons.com" title="ScottsBassLessons.com" tabindex="-1">Online Bass Lessons</a></h1>
	
<form name="loginform" id="loginform" action="https://www.scottsbasslessons.com/wp-login.php" method="post">
	<p>
		<label for="user_login">Username or Email Address<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">My Password:<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
		<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
		<input type="hidden" name="redirect_to" value="https://www.scottsbasslessons.com/wp-admin/" />
		<input type="hidden" name="testcookie" value="1" />
	</p>
</form>

<p id="nav">
	<a href="https://www.scottsbasslessons.com/wp-login.php?action=lostpassword">Lost your password?</a>
</p>

<script type="text/javascript">
function wp_attempt_focus(){
setTimeout( function(){ try{
d = document.getElementById('user_login');
d.focus();
d.select();
} catch(e){}
}, 200);
}

wp_attempt_focus();
if(typeof wpOnload=='function')wpOnload();
</script>

	<p id="backtoblog"><a href="http://www.scottsbasslessons.com/">&larr; Back to Online Bass Lessons</a></p>
	
	</div>

	
	<script type='text/javascript' src='https://www.scottsbasslessons.com/wp-content/plugins/s2member/s2member-o.php?ws_plugin__s2member_js_w_globals=1&#038;qcABC=1&#038;ver=160801-160801-2329250881'></script>
<script type="text/javascript">/*<![CDATA[*/if ( !window.TL_Const ) var TL_Const={"security":"7113719a53","ajax_url":"https:\/\/www.scottsbasslessons.com\/wp-admin\/admin-ajax.php","action_conversion":"tve_leads_ajax_conversion","action_impression":"tve_leads_ajax_impression","custom_post_data":{"http_referrer":"http:\/\/www.scottsbasslessons.com\/wp-login.php?action=lostpassword"},"current_screen":{"screen_type":7,"screen_id":0},"ignored_fields":["email","_captcha_size","_captcha_theme","_captcha_type","_submit_option","_use_captcha","g-recaptcha-response","__tcb_lg_fc","__tcb_lg_msg","_state","_form_type","_error_message_option","_back_url","_submit_option","url","_asset_group","_asset_option","mailchimp_optin"]}/*]]> */</script>	<div class="clear"></div>
	</body>
	</html>
	